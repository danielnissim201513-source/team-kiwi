require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const session = require("express-session");
const SQLiteStoreFactory = require("connect-sqlite3");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const SQLiteStore = SQLiteStoreFactory(session);
const db = new Database(path.join(__dirname, "team-kiwi.sqlite"));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'member',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL,
 role TEXT NOT NULL,
 body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const adminName = process.env.ADMIN_USERNAME || "Daniel";
const adminPass = process.env.ADMIN_PASSWORD || "ChangeThisPassword123!";
if (adminPass === "ChangeThisPassword123!") {
  console.warn("IMPORTANT: Set ADMIN_PASSWORD in .env before sharing this site.");
}
const existingAdmin = db.prepare("SELECT id FROM users WHERE username = ?").get(adminName);
if (!existingAdmin) {
  db.prepare("INSERT INTO users (username,password_hash,role) VALUES (?,?,?)")
    .run(adminName, bcrypt.hashSync(adminPass, 12), "admin");
}

app.use(express.json({ limit: "20kb" }));
const sessionMiddleware = session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: __dirname }),
  secret: process.env.SESSION_SECRET || "dev-secret-change-this-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);
app.use(express.static(path.join(__dirname, "public")));

const cleanText = (value, max) => String(value || "").trim().slice(0, max);
function currentUser(req) {
  return req.session.user || null;
}
function requireAuth(req, res, next) {
  if (!currentUser(req)) return res.status(401).json({ error: "צריך להתחבר קודם" });
  next();
}
function requireAdmin(req, res, next) {
  if (!currentUser(req) || currentUser(req).role !== "admin") return res.status(403).json({ error: "רק מנהל יכול לבצע את הפעולה" });
  next();
}

app.get("/api/me", (req, res) => res.json({ user: currentUser(req) }));
app.post("/api/register", async (req, res) => {
  const username = cleanText(req.body.username, 20);
  const password = String(req.body.password || "");
  if (!/^[\p{L}\p{N}_]{3,20}$/u.test(username)) return res.status(400).json({ error: "שם משתמש: 3–20 תווים, אותיות/מספרים/קו תחתון בלבד" });
  if (password.length < 8) return res.status(400).json({ error: "הסיסמה חייבת להכיל לפחות 8 תווים" });
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users (username,password_hash) VALUES (?,?)").run(username, hash);
    req.session.user = { id: Number(info.lastInsertRowid), username, role: "member" };
    res.json({ user: req.session.user });
  } catch {
    res.status(409).json({ error: "שם המשתמש כבר תפוס" });
  }
});
app.post("/api/login", async (req, res) => {
  const username = cleanText(req.body.username, 20);
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "שם משתמש או סיסמה שגויים" });
  req.session.user = { id: user.id, username: user.username, role: user.role };
  res.json({ user: req.session.user });
});
app.post("/api/logout", requireAuth, (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/messages", requireAuth, (req, res) => {
  res.json(db.prepare("SELECT id,username,role,body,created_at FROM messages ORDER BY id DESC LIMIT 100").all().reverse());
});
app.get("/api/announcements", (req, res) => {
  res.json(db.prepare("SELECT * FROM announcements ORDER BY id DESC LIMIT 10").all());
});
app.get("/api/admin/stats", requireAuth, requireAdmin, (req, res) => {
  res.json({
    users: db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
    messages: db.prepare("SELECT COUNT(*) AS n FROM messages").get().n
  });
});
app.post("/api/admin/announcement", requireAuth, requireAdmin, (req, res) => {
  const title = cleanText(req.body.title, 70);
  const body = cleanText(req.body.body, 500);
  if (!title || !body) return res.status(400).json({ error: "צריך למלא כותרת והודעה" });
  db.prepare("INSERT INTO announcements(title,body) VALUES (?,?)").run(title, body);
  io.emit("announcement", { title, body });
  res.json({ ok: true });
});
app.delete("/api/admin/messages/:id", requireAuth, requireAdmin, (req, res) => {
  db.prepare("DELETE FROM messages WHERE id = ?").run(Number(req.params.id));
  io.emit("message-deleted", Number(req.params.id));
  res.json({ ok: true });
});

io.on("connection", socket => {
  const user = socket.request.session?.user;
  if (!user) return;
  socket.join("members");
  socket.emit("online-count", io.sockets.adapter.rooms.get("members")?.size || 0);
  io.to("members").emit("online-count", io.sockets.adapter.rooms.get("members")?.size || 0);
  socket.on("chat-message", raw => {
    const body = cleanText(raw, 500);
    if (!body) return;
    const info = db.prepare("INSERT INTO messages(username,role,body) VALUES (?,?,?)")
      .run(user.username, user.role, body);
    const message = db.prepare("SELECT id,username,role,body,created_at FROM messages WHERE id=?").get(info.lastInsertRowid);
    io.to("members").emit("chat-message", message);
  });
  socket.on("disconnect", () => {
    io.to("members").emit("online-count", Math.max(0, (io.sockets.adapter.rooms.get("members")?.size || 1) - 1));
  });
});

server.listen(PORT, () => console.log(`Team Kiwi is running at http://localhost:${PORT}`));
