let mode = "login";
let me = null;
let socket = null;
const $ = id => document.getElementById(id);
const authPanel = $("authPanel"), memberArea = $("memberArea");
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  mode=btn.dataset.tab;
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  $("authSubmit").textContent=mode==="login"?"כניסה לקהילה ←":"יצירת חשבון ←";
  $("password").autocomplete=mode==="login"?"current-password":"new-password";
  $("authError").textContent="";
}));
$("joinBtn").addEventListener("click",()=>{document.querySelector("#community").scrollIntoView({behavior:"smooth"});$("username").focus()});
async function api(url, options={}) {
  const res=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||"משהו השתבש");
  return data;
}
$("authForm").addEventListener("submit",async e=>{
  e.preventDefault();$("authError").textContent="";
  try{
    const data=await api("/api/"+(mode==="login"?"login":"register"),{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})});
    await enter(data.user);
  }catch(err){$("authError").textContent=err.message;}
});
async function enter(user){
  me=user;authPanel.classList.add("hidden");memberArea.classList.remove("hidden");
  $("welcomeName").textContent=user.username;$("navUser").textContent="שלום, "+user.username;
  $("roleBadge").textContent=user.role==="admin"?"ADMIN":"MEMBER";
  $("adminPanel").classList.toggle("hidden",user.role!=="admin");
  await loadAnnouncements();await loadMessages();
  if(user.role==="admin") await loadStats();
  socket=io();
  socket.on("chat-message",addMessage);
  socket.on("message-deleted",id=>{const node=document.querySelector(`[data-message="${id}"]`);if(node)node.remove()});
  socket.on("online-count",n=>{$("onlineCount").textContent=n;$("chatOnline").textContent=n});
  socket.on("announcement",async()=>{await loadAnnouncements();toast("📢 פורסמה הכרזה חדשה!")});
  $("memberArea").scrollIntoView({behavior:"smooth",block:"start"});
}
$("logoutBtn").addEventListener("click",async()=>{if(socket)socket.disconnect();await api("/api/logout",{method:"POST"});me=null;memberArea.classList.add("hidden");authPanel.classList.remove("hidden");$("navUser").textContent="";toast("התנתקת מהקהילה")});
function addMessage(m){
  const box=$("messages");const empty=box.querySelector(".empty-chat");if(empty)empty.remove();
  if(box.querySelector(`[data-message="${m.id}"]`))return;
  const el=document.createElement("div");el.className="message"+(m.username===me.username?" mine":"");el.dataset.message=m.id;
  const admin=m.role==="admin";
  el.innerHTML=`<div class="message-meta"><b>${escapeHtml(m.username)}</b>${admin?'<span>🛡️ מנהל</span>':''}<small>${new Date(m.created_at+"Z").toLocaleTimeString("he-IL",{hour:"2-digit",minute:"2-digit"})}</small>${me.role==="admin"?`<button class="delete-msg" data-delete="${m.id}">מחיקה</button>`:""}</div><p>${escapeHtml(m.body)}</p>`;
  box.appendChild(el);box.scrollTop=box.scrollHeight;
}
async function loadMessages(){const list=await api("/api/messages");$("messages").innerHTML="";if(!list.length)$("messages").innerHTML='<div class="empty-chat">🥝<br>מתחילים את השיחה הראשונה!</div>';list.forEach(addMessage)}
$("chatForm").addEventListener("submit",e=>{e.preventDefault();const val=$("chatInput").value.trim();if(!val||!socket)return;socket.emit("chat-message",val);$("chatInput").value=""});
$("messages").addEventListener("click",async e=>{const btn=e.target.closest("[data-delete]");if(!btn)return;try{await api("/api/admin/messages/"+btn.dataset.delete,{method:"DELETE"});toast("ההודעה נמחקה")}catch(err){toast(err.message)}});
async function loadAnnouncements(){const list=await api("/api/announcements");$("announcementList").innerHTML=list.length?list.map(a=>`<article class="announcement-item"><b>${escapeHtml(a.title)}</b><p>${escapeHtml(a.body)}</p></article>`).join(""):'<p class="muted">עדיין אין הכרזות חדשות.</p>'}
async function loadStats(){const s=await api("/api/admin/stats");$("adminUsers").textContent=s.users;$("adminMessages").textContent=s.messages;$("memberCount").textContent=s.users}
$("announcementForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/announcement",{method:"POST",body:JSON.stringify({title:$("announcementTitle").value,body:$("announcementBody").value})});$("announcementTitle").value="";$("announcementBody").value="";await loadAnnouncements();toast("ההכרזה פורסמה!")}catch(err){toast(err.message)}});
(async()=>{try{const data=await api("/api/me");if(data.user)await enter(data.user);else $("memberCount").textContent="🥝"}catch{}})();
